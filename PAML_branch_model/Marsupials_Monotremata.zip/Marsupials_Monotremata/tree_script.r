library(ape)
a<-read.tree("Marsupials_Monotremata_C9.nwk")
b<-unroot(a)
write.tree(b,"Marsupials_Monotremata_C9.nwk.tree")
