library(ape)
a<-read.tree("Carnivora_C9.nwk")
b<-unroot(a)
write.tree(b,"Carnivora_C9.nwk.tree")
