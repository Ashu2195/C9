library(ape)
a<-read.tree("Insectivora_C9.nwk")
b<-unroot(a)
write.tree(b,"Insectivora_C9.nwk.tree")
