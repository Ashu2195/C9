library(ape)
a<-read.tree("Actinopterygii_C9.nwk")
b<-unroot(a)
write.tree(b,"Actinopterygii_C9.nwk.tree")
