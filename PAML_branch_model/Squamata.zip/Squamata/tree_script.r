library(ape)
a<-read.tree("Squamata_C9.nwk")
b<-unroot(a)
write.tree(b,"Squamata_C9.nwk.tree")
