library(ape)
a<-read.tree("Xenarthra_C9.nwk")
b<-unroot(a)
write.tree(b,"Xenarthra_C9.nwk.tree")
