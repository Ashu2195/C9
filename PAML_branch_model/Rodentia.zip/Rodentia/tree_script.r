library(ape)
a<-read.tree("Rodentia_C9.nwk")
b<-unroot(a)
write.tree(b,"Rodentia_C9.nwk.tree")
