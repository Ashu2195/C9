library(ape)
a<-read.tree("Perissodactyla_C9.nwk")
b<-unroot(a)
write.tree(b,"Perissodactyla_C9.nwk.tree")
