library(ape)
a<-read.tree("Testudines_C9.nwk")
b<-unroot(a)
write.tree(b,"Testudines_C9.nwk.tree")
