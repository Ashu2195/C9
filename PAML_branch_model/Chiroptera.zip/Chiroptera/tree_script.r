library(ape)
a<-read.tree("Chiroptera_C9.nwk")
b<-unroot(a)
write.tree(b,"Chiroptera_C9.nwk.tree")
